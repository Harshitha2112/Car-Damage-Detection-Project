# car damage severity  > 2026-09-04 11:47am
https://universe.roboflow.com/models-rdrt2/car-damage-severity-nynst-02uyv

Provided by a Roboflow user
License: CC BY 4.0

